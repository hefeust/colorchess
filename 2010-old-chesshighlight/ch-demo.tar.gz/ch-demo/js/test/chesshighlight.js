
Event.observe(window, 'load', function() {

//	console.log(Partie);
//	console.log(Mouvement);
//	console.log(DeplacementResultat);

	console.log(Carre);
	console.log(Echiquier);
	
	// var  LigneDeCommande;
	
});
