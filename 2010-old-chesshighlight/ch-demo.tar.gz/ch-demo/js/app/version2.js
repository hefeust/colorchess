
require('js/version2', function(v2) { 
	return {
	
		Camps : function(selector) {
			return v2.Camps;
		}
		
		RefAgebr : function(ref) {
			return v2.RefAlgebr;
		}
	
	};

});
